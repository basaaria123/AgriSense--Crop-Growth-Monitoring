"""
AgriSense - synthetic crop-growth dataset generator (Tomato, Marigold, Mint).
Mechanistic simulation: a daily 'growth-rate factor' (0-1) is computed from temperature,
soil moisture, light (DLI) and soil pH; it advances a 'physiological time' clock that
drives a sigmoid growth curve. Stress therefore slows growth and delays stages.
Reference ranges come from the papers listed in docs/reference_anchors.csv; values marked
'assumption' there are NOT from a source. ALL OUTPUT IS SYNTHETIC.
Usage: python generate_synthetic_growth_data.py [output_dir] [seed]
"""
import sys, os
import numpy as np, pandas as pd

OUT = sys.argv[1] if len(sys.argv) > 1 else "data"
SEED = int(sys.argv[2]) if len(sys.argv) > 2 else 2026
rng = np.random.default_rng(SEED)
os.makedirs(OUT, exist_ok=True)

def trap(x, a, b, c, d):
    up = np.clip((x - a) / (b - a), 0, 1); dn = np.clip((d - x) / (d - c), 0, 1)
    return float(np.minimum(up, dn))
def sig(p, p50, k): return 1 / (1 + np.exp(-k * (p - p50)))
def prog(p, p50, k):
    g0 = sig(0, p50, k); return float(np.clip((sig(p, p50, k) - g0) / (1 - g0), 0, 1))
def nrm(mu, sd, lo, hi): return float(np.clip(rng.normal(mu, sd), lo, hi))

CFG = {
 "Marigold": dict(T=(8,20,30,38), M=(8,22,44,58), PH=(4.5,6.0,7.0,8.5), L=(4,14,40,65), base_T=27, base_ph=6.5, days=100, irr=26),
 "Mint":     dict(T=(4,15,25,36), M=(10,28,45,62), PH=(4.5,5.5,6.5,8.0), L=(4,12,35,60), base_T=21, base_ph=6.0, days=120, irr=32),
 "Tomato":   dict(T=(10,20,27,36), M=(8,24,44,58), PH=(4.5,6.0,6.8,8.2), L=(5,15,40,65), base_T=25, base_ph=6.4, days=130, irr=28),
}
SCEN = ["normal"]*15 + ["drought"]*3 + ["heat"]*3 + ["low_light"]*3 + ["overwatering"]*3 + ["ph_stress"]*3

def env_series(crop, scen):
    c = CFG[crop]; n = c["days"]
    stress = np.array(["none"] * n, dtype=object)
    tm = np.zeros(n); ar = 0.0
    for d in range(n):
        ar = 0.7 * ar + rng.normal(0, 1.0)
        tm[d] = c["base_T"] + 2 * np.sin(2 * np.pi * d / (2 * n)) + ar
    def win(lo, hi, ln_lo, ln_hi):
        s = int(rng.integers(lo, hi)); l = int(rng.integers(ln_lo, ln_hi)); return s, min(n, s + l)
    if scen == "heat":
        s, e = win(25, 55, 7, 13); tm[s:e] += rng.uniform(5, 7.5); stress[s:e] = "heat"
    tmax = tm + rng.uniform(3, 6, n); tmin = tm - rng.uniform(3, 6, n)
    hum = np.clip(62 - 1.6 * (tm - c["base_T"]) + rng.normal(0, 5, n), 30, 95)
    dli = np.clip(32 + rng.normal(0, 5, n), 8, 60)
    if scen == "low_light":
        s, e = win(25, 55, 10, 17); dli[s:e] *= rng.uniform(0.25, 0.4); stress[s:e] = "low_light"
    dr = ov = (0, 0)
    if scen == "drought": dr = win(25, 55, 10, 17); stress[dr[0]:dr[1]] = "drought"
    if scen == "overwatering": ov = win(25, 55, 8, 15); stress[ov[0]:ov[1]] = "overwatering"
    m = rng.uniform(34, 42); sm = np.zeros(n)
    for d in range(n):
        et = max(0.8, 1.8 + 0.12 * (tm[d] - 25) + 0.02 * (dli[d] - 32))
        m -= et
        in_dr = dr[0] <= d < dr[1]
        if ov[0] <= d < ov[1]: m = rng.uniform(55, 62)
        elif m < c["irr"] and not in_dr: m = rng.uniform(36, 44)
        sm[d] = np.clip(m + rng.normal(0, 0.8), 5, 65)
    ph = c["base_ph"] + np.cumsum(rng.normal(0, 0.01, n)) + rng.normal(0, 0.05, n)
    if scen == "ph_stress":
        onset = int(rng.integers(20, 40)); target = rng.choice([c["PH"][1] - 0.4, c["PH"][2] + 0.4])
        for d in range(onset, n):
            ph[d] = ph[onset - 1] + (target - ph[onset - 1]) * min(1, (d - onset + 1) / 5) + rng.normal(0, 0.05)
        stress[onset:] = "ph_stress"
    st = tm - 1.5 + rng.normal(0, 0.4, n)
    return tm, tmax, tmin, hum, dli, sm, st, ph, stress

def factor(crop, t, m, l, ph):
    c = CFG[crop]
    return max(0.02, trap(t, *c["T"]) * trap(m, *c["M"]) * trap(l, *c["L"]) * trap(ph, *c["PH"]))

def size_scale(crop, env):
    fs = [factor(crop, env[0][i], env[5][i], env[4][i], env[7][i]) for i in range(len(env[0]))]
    return min(1.0, float(np.mean(fs)) / 0.95) ** 1.0   # season-long stress also reduces final size

def condition(f): return "healthy" if f >= 0.85 else ("mild_stress" if f >= 0.6 else "stressed")
def stage_of(p, bounds):
    for name, hi in bounds:
        if p < hi: return name
    return bounds[-1][0]

def base_row(pid, crop, typ, scen, d, env, i, f, p, stage):
    tm, tmax, tmin, hum, dli, sm, st, ph, stress = env
    return dict(plant_id=pid, crop=crop, type=typ, scenario=scen, day_after_transplant=d, stage=stage,
        air_temp_mean_c=round(tm[i],1), air_temp_max_c=round(tmax[i],1), air_temp_min_c=round(tmin[i],1),
        humidity_pct=round(hum[i],1), light_dli_mol_m2_d=round(dli[i],1), soil_moisture_pct=round(sm[i],1),
        soil_temp_c=round(st[i],1), soil_ph=round(ph[i],2), active_stress=stress[i],
        growth_rate_factor=round(f,3), physiological_time=round(p,1), growth_condition=condition(f))

def noisy(v, sd=0.015): return v * rng.normal(1, sd)

# ---------------- Marigold ----------------
def marigold(idx, typ, scen):
    pid = f"MAR-{typ[0]}-{idx:03d}"; env = env_series("Marigold", scen); n = CFG["Marigold"]["days"]
    A = typ == "African"
    Hmax = nrm(66,10,45,95) if A else nrm(30,4,20,40); h0 = 8 if A else 6
    Smax = nrm(52,8,35,70) if A else nrm(30,4,20,42)
    Bmax = nrm(14,3,7,22) if A else nrm(18,3.5,10,28)
    Lmax = nrm(130,20,80,190) if A else nrm(150,25,90,210)
    Fmax = nrm(40,10,18,70) if A else nrm(55,12,25,90)
    Dmax = nrm(7,0.8,5,9.5) if A else nrm(4,0.5,3,5.5)
    S = size_scale("Marigold", env); Hmax*=S; Smax*=S; Bmax*=S; Lmax*=S; Fmax*=S; Dmax*=(0.85+0.15*S)
    p50, k, pfl = (36, .11, 48) if A else (30, .12, 42)
    bounds = [("seedling",12),("vegetative",32),("branching",pfl),("flowering",85),("mature_senescence",999)]
    r = nrm(1,0.06,0.85,1.15); p = 0.0; rows = []; last = dict(h=0,s=0,b=0,l=0)
    for i in range(n):
        f = factor("Marigold", env[0][i], env[5][i], env[4][i], env[7][i]); p += f * r
        q = prog(p, p50, k)
        h = max(last["h"], noisy(h0 + (Hmax - h0) * q)); s = max(last["s"], noisy(Smax * prog(p, p50 + 4, k)))
        b = max(last["b"], round(Bmax * prog(p, p50 - 6, k))); l = max(last["l"], round(noisy(Lmax * prog(p, p50 - 2, k))))
        last.update(h=h, s=s, b=b, l=l)
        fl = 0 if p < pfl else Fmax * sig(p, pfl + 6, .3) * (1 - .75 * sig(p, 92, .25))
        fl = int(round(max(0, noisy(fl, .05))))
        dia = round(noisy(Dmax * (0.7 + 0.3 * prog(p, pfl + 10, .2)), .03), 1) if fl > 0 else np.nan
        row = base_row(pid, "Marigold", typ + " marigold", scen, i + 1, env, i, f, p, stage_of(p, bounds))
        row.update(height_cm=round(h,1), spread_cm=round(s,1), primary_branches=int(b), leaf_count=int(l), flower_count=fl, flower_diameter_cm=dia)
        rows.append(row)
    return rows

# ---------------- Mint ----------------
def mint(idx, typ, scen):
    pid = f"MIN-{typ[0]}-{idx:03d}"; env = env_series("Mint", scen); n = CFG["Mint"]["days"]
    P = typ == "Peppermint"
    Hmax = nrm(52,7,38,68) if P else nrm(58,8,42,75); h0 = 5
    Lmax = nrm(170,25,110,230); LL = nrm(5.5,.6,4,7) if P else nrm(6.5,.7,5,8.5)
    Smax = nrm(8,1.3,5,11); FW = nrm(42,8,25,65)
    S = size_scale("Mint", env); Hmax*=S; Lmax*=S; Smax*=S; FW*=S
    r = nrm(1,0.06,0.85,1.15); p = 0.0; p2 = 0.0; cycle = 1; rows = []; cut = None
    for i in range(n):
        f = factor("Mint", env[0][i], env[5][i], env[4][i], env[7][i]); harvest = 0
        if cycle == 1:
            p += f * r; q = prog(p, 32, .09)
            h = h0 + (Hmax - h0) * q; l = Lmax * prog(p, 30, .09); ptot = p
            stage = stage_of(p, [("establishment",14),("vegetative",48),("pre_harvest",999)])
            if p >= 65: harvest = 1; cut = (h, l)
        else:
            p2 += f * r; q = prog(p2, 22, .10); hs, ls = 0.25 * cut[0], 0.3 * cut[1]
            h = hs + (0.92 * Hmax - hs) * q; l = ls + (0.9 * Lmax - ls) * q; ptot = 65 + p2
            stage = stage_of(p2, [("regrowth",40),("pre_harvest",999)])
        h = noisy(h); l = round(noisy(l)); st = Smax * prog(ptot, 70, .045)
        fw = FW * (h / Hmax) * (max(l, 1) / Lmax) ** .5
        ll = LL * (0.3 + 0.7 * min(1, h / Hmax))
        row = base_row(pid, "Mint", typ, scen, i + 1, env, i, f, ptot, stage)
        row.update(height_cm=round(h,1), leaf_count=int(l), leaf_length_cm=round(noisy(ll,.03),1), stolon_count=int(round(st)),
                   shoot_fresh_weight_g=round(noisy(fw,.04),1), cycle=cycle, harvest_event=harvest)
        rows.append(row)
        if harvest: cycle = 2
    # stolons never decrease
    mx = 0
    for rw in rows: mx = max(mx, rw["stolon_count"]); rw["stolon_count"] = mx
    return rows

# ---------------- Tomato ----------------
def tomato(idx, typ, scen):
    pid = f"TOM-{typ[:3].upper()}-{idx:03d}"; env = env_series("Tomato", scen); n = CFG["Tomato"]["days"]
    D = typ == "Determinate"
    Hmax = nrm(90,10,65,115) if D else nrm(200,25,150,260); h0 = 12
    p50, k = (34, .10) if D else (62, .055)
    Lmax = nrm(28,4,18,40) if D else nrm(48,6,32,65)
    Amax = nrm(6000,900,3500,9000) if D else nrm(11000,1600,7000,16000)
    Fl = nrm(24,5,12,40) if D else nrm(14,3,7,24)
    Fm = nrm(30,6,15,48) if D else nrm(55,10,30,85)
    Wmax = nrm(95,15,60,140) if D else nrm(115,20,70,170)
    S = size_scale("Tomato", env); Hmax*=S; Lmax*=S; Amax*=S; Fl*=S; Fm*=S; Wmax*=(0.85+0.15*S)
    sh = 0 if D else 5
    bounds = [("seedling",14),("vegetative",36+sh),("inflorescence_emergence",46+sh),("flowering",60+sh),("fruit_development",88+sh),("ripening_harvest",999)]
    r = nrm(1,0.06,0.85,1.15); p = 0.0; rows = []; last = dict(h=0,l=0,a=0,fr=0,rd=0)
    for i in range(n):
        f = factor("Tomato", env[0][i], env[5][i], env[4][i], env[7][i]); p += f * r
        h = max(last["h"], noisy(h0 + (Hmax - h0) * prog(p, p50, k)))
        l = max(last["l"], round(noisy(Lmax * prog(p, p50 - 4, k))))
        a = max(last["a"], noisy(Amax * prog(p, p50 + 4, k), .03))
        if D: fl = Fl * np.exp(-0.5 * ((p - 54) / 9) ** 2) if p >= 36 else 0
        else: fl = Fl * sig(p, 50, .3) if p >= 36 else 0
        fl = int(round(max(0, noisy(fl, .06))))
        if p < 48: fr = 0
        elif D: fr = Fm * sig(p, 62, .25)
        else: fr = Fm * sig(p, 80, .07)
        fr = max(last["fr"], int(round(fr)))
        rp = 90 if D else 102
        rd = min(fr, max(last["rd"], int(round(fr * sig(p, rp, .22) * (1 if D else .7)))))
        mw = round(noisy(Wmax * prog(p, 75, .07), .04), 1) if fr > 0 else np.nan
        last.update(h=h, l=l, a=a, fr=fr, rd=rd)
        row = base_row(pid, "Tomato", typ, scen, i + 1, env, i, f, p, stage_of(p, bounds))
        row.update(height_cm=round(h,1), leaf_count=int(l), leaf_area_cm2=int(a), flower_count=fl, fruit_count=fr, red_fruit_count=rd, mean_fruit_weight_g=mw)
        rows.append(row)
    return rows

def build(name, fn, types, crop_label):
    allr = []
    for typ in types:
        sc = list(rng.permutation(SCEN))
        for i in range(1, 31): allr += fn(i, typ, sc[i - 1])
    df = pd.DataFrame(allr); df.to_csv(os.path.join(OUT, name), index=False); return df

mar = build("marigold_growth_timeseries.csv", marigold, ["African", "French"], "Marigold")
mnt = build("mint_growth_timeseries.csv", mint, ["Peppermint", "Spearmint"], "Mint")
tom = build("tomato_growth_timeseries.csv", tomato, ["Determinate", "Indeterminate"], "Tomato")
comb = pd.concat([mar, mnt, tom], ignore_index=True)
cols = list(comb.columns); first = ["plant_id","crop","type","scenario","day_after_transplant","stage","growth_condition","active_stress"]
comb = comb[first + [c for c in cols if c not in first]]
comb.to_csv(os.path.join(OUT, "all_crops_combined.csv"), index=False)
print({n: len(d) for n, d in [("marigold", mar), ("mint", mnt), ("tomato", tom)]})
