# AgriSense Synthetic Crop Growth Datasets

**ALL DATA HERE IS SYNTHETIC (simulated).** It fills the gaps found in the dataset search for
marigold, mint and tomato growth monitoring. Do not present it as measured field data.

## Contents
| File | Rows | What it holds |
|---|---|---|
| data/marigold_growth_timeseries.csv | 6,000 | 60 plants (30 African, 30 French), 100 days |
| data/mint_growth_timeseries.csv | 7,200 | 60 plants (30 Peppermint, 30 Spearmint), 120 days, one harvest/regrowth cycle |
| data/tomato_growth_timeseries.csv | 7,800 | 60 plants (30 Determinate, 30 Indeterminate), 130 days |
| data/all_crops_combined.csv | 21,000 | All three, shared columns first |
| docs/data_dictionary.csv | | Every column with unit |
| docs/stage_definitions.csv | | Stage rules per crop |
| docs/reference_anchors.csv | | Which numbers come from papers and which are assumptions |
| docs/dataset_summary.csv | | Plants, rows, height summary |
| code/generate_synthetic_growth_data.py | | Regenerate or resize (`python generate_synthetic_growth_data.py out_dir seed`) |

Each plant is one pot with its own daily sensors: temperature, humidity, light (DLI), soil moisture,
soil temperature, soil pH, plus measured growth parameters and a stage label.
Per crop type, 15 plants are normal and 3 each have drought, heat, low light, overwatering or pH stress.

## How it was generated
A daily growth-rate factor (0-1) is computed from temperature, soil moisture, light and pH.
It advances a physiological-time clock that drives sigmoid growth curves, so stress slows growth,
delays stages and shrinks final size. Plants differ by random size and speed, and measurements carry noise.

## Limits (read before using)
- Plausible ranges come from the papers in reference_anchors.csv, but many values are **assumptions** (marked there), especially French marigold, spearmint and all tomato size values.
- Relationships (for example temperature vs growth) are built into the simulator, so a model trained here will mostly learn the simulator. Use it for prototyping the pipeline, dashboards and alerts, and **validate with real measurements**.
- `growth_condition` is environmental stress, not disease. No disease labels are included.
- No images are included. Collect your own labelled images (or use TomatoMAP for tomato) and match them to the `stage` names.
- Keep synthetic data out of validation/test sets; label it as synthetic in your project report.
